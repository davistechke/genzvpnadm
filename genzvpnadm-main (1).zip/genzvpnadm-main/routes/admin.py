import json
import re
from datetime import datetime, timedelta

from flask import (Blueprint, Response, current_app, flash, redirect, render_template, request, session, url_for)

from models import (REQUEST_KINDS, REQUEST_STATUSES, Ad, Admin, ApkRelease, FreeApp, Notice, Presence, PresenceUsage, Tweak,
                    UserRequest, bump_rev, db, get_setting, set_setting, slugify, utcnow)
from routes.common import (admin_required, check_csrf, clear_failures, current_admin, record_failure,
                           throttled)
from services import apk as apk_service
from services import freeapps as free_service
from services import links
from services.bundle import FORMAT, build_bundle, import_bundle
from services.lock import is_locked, lock, unlock

bp = Blueprint("admin", __name__, url_prefix="/admin")
PROTOCOLS = ("ssh", "v2ray", "udp", "wireguard", "custom")


@bp.before_request
def _csrf():
    check_csrf()


# ------------------------------------------------------------------ auth

@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_admin():
        return redirect(url_for("admin.home"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        key = f"admin:{email}:{request.remote_addr}"
        if throttled(key):
            flash("Too many attempts. Try again in a few minutes.", "error")
        else:
            a = Admin.query.filter_by(email=email).first()
            if a and a.check_password(request.form.get("password", "")):
                clear_failures(key)
                session.clear()
                session["admin_uid"] = a.id
                return redirect(url_for("admin.home"))
            record_failure(key)
            flash("Wrong email or password.", "error")
    return render_template("admin_login.html")


@bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("admin.login"))


@bp.post("/password")
@admin_required
def change_password():
    a = current_admin()
    if not a.check_password(request.form.get("current", "")) or len(request.form.get("new", "")) < 8:
        flash("Current password is wrong, or the new one is shorter than 8 characters.", "error")
    else:
        a.set_password(request.form["new"])
        db.session.commit()
        flash("Password changed.", "ok")
    return redirect(url_for("admin.home", tab="settings"))


# ------------------------------------------------------------------ pages

def _ago(delta):
    s = max(int(delta.total_seconds()), 0)
    if s < 60:
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m {s % 60:02d}s"
    return f"{s // 3600}h {(s % 3600) // 60:02d}m"


@bp.get("")
@bp.get("/")
@admin_required
def home():
    tab = request.args.get("tab", "tweaks")
    ctx = {"tab": tab}
    ctx["tweaks"] = Tweak.query.order_by(Tweak.sort, Tweak.name).all()
    ctx["channel_url"] = get_setting("channel_url", "")
    ctx["notices"] = Notice.query.order_by(Notice.id.desc()).limit(50).all()
    ctx["ads"] = Ad.query.order_by(Ad.id.desc()).limit(50).all()
    ctx["rev"] = get_setting("rev", "0")
    ctx["locked"] = bool(current_app.config["CONFIG_KEY"])
    cutoff = utcnow() - timedelta(seconds=current_app.config["ONLINE_SECONDS"])
    ctx["online_count"] = Presence.query.filter(Presence.last_seen >= cutoff).count()
    ctx["new_requests"] = UserRequest.query.filter_by(status="new").count()
    if tab == "online":
        now = utcnow()
        rows = Presence.query.filter(Presence.last_seen >= cutoff).order_by(Presence.connected_at).all()
        names = {t.id: t.name for t in Tweak.query.all()}
        used = {u.device: u for u in PresenceUsage.query.all()}
        ctx["online"] = [{
            "down": used[r.device].down if r.device in used else 0, "up": used[r.device].up if r.device in used else 0,
            "tweak": names.get(r.tweak_id) or r.tweak_name or "unknown", "ip": r.ip, "exit_ip": r.exit_ip,
            "version": r.app_version, "for": _ago(now - r.connected_at), "seen": int((now - r.last_seen).total_seconds()),
            "device": r.device[:6],
        } for r in rows]
        ctx["now_down"] = sum(o["down"] for o in ctx["online"])
        ctx["now_up"] = sum(o["up"] for o in ctx["online"])
        ctx["all_down"] = int(get_setting("usage_down_total", "0") or 0)
        ctx["all_up"] = int(get_setting("usage_up_total", "0") or 0)
        per = {}
        for o in ctx["online"]:
            per[o["tweak"]] = per.get(o["tweak"], 0) + 1
        ctx["per_tweak"] = sorted(per.items(), key=lambda kv: -kv[1])
    if tab == "app":
        ctx["releases"] = ApkRelease.query.order_by(ApkRelease.created_at.desc(), ApkRelease.id.desc()).all()
        ctx["st"] = apk_service.stats()
        ctx["apps"] = sorted({r.app_name for r in ctx["releases"]})
        ctx["slugify"] = slugify
        ctx["max_mb"] = current_app.config["MAX_UPLOAD_MB"]
    if tab == "freeapps":
        ctx["free_apps"] = FreeApp.query.order_by(FreeApp.created_at.desc(), FreeApp.id.desc()).all()
        ctx["fst"] = free_service.stats()
        ctx["max_mb"] = current_app.config["FREE_APP_MAX_MB"]
    if tab == "requests":
        show = request.args.get("show", "open")
        q = UserRequest.query
        if show == "open":
            q = q.filter(UserRequest.status != "done")
        elif show == "done":
            q = q.filter_by(status="done")
        ctx["show"] = show
        ctx["reqs"] = q.order_by(UserRequest.id.desc()).limit(200).all()
        ctx["kind_names"] = dict(REQUEST_KINDS)
        ctx["statuses"] = REQUEST_STATUSES
    return render_template("admin.html", **ctx)


# ------------------------------------------------------------------ tweaks

def _tweak_values(s):
    cfg = s.cfg if s else {}
    return {
        "name": s.name if s else "", "country_code": s.country_code if s else "KE",
        "protocol": s.protocol if s else "ssh", "host": s.host if s else "", "port": s.port if s else 22,
        "description": s.description if s else "", "sort": s.sort if s else 0, "is_active": s.is_active if s else True,
        "expires_at": s.expires_at.strftime("%Y-%m-%d") if s and s.expires_at else "",
        "ssh_username": cfg.get("username", ""), "ssh_password": cfg.get("password", ""),
        "ssh_payload": cfg.get("payload", ""), "ssh_sni": cfg.get("sni", ""),
        "ssh_proxy": (f"{cfg['proxy_host']}:{cfg.get('proxy_port') or ''}".rstrip(":") if cfg.get("proxy_host") else ""),
        "v2ray_link": cfg.get("link", ""),
        "v2_proto": cfg.get("form", {}).get("proto", "vless"), "v2_uuid": cfg.get("form", {}).get("uuid", ""),
        "v2_network": cfg.get("form", {}).get("network", "ws"), "v2_path": cfg.get("form", {}).get("path", ""),
        "v2_hosthdr": cfg.get("form", {}).get("host_header", ""), "v2_sni": cfg.get("form", {}).get("sni", ""),
        "v2_tls": cfg.get("form", {}).get("tls", True),
        "udp_server": _udp_server(s),
        "udp_username": cfg.get("form", {}).get("username", ""), "udp_password": cfg.get("form", {}).get("password", ""),
        "udp_sni": cfg.get("form", {}).get("sni", ""), "udp_pin": cfg.get("form", {}).get("pin", ""),
        "udp_certname": cfg.get("form", {}).get("cert_name", ""),
        "wg_conf": cfg.get("wg_conf", ""),
        "custom_outbound": json.dumps(cfg["outbound"], indent=2) if s and s.protocol == "custom" and cfg.get("outbound") else "",
    }


def _parse_proxy(text):
    """'host:port' (optionally with http://) -> (host, port). Empty means no proxy."""
    text = re.sub(r"^https?://", "", (text or "").strip()).rstrip("/")
    if not text:
        return "", 0
    host, _, port = text.rpartition(":")
    if not host:
        return text, 80  # host only: plain HTTP proxy port, which is what injector apps assume
    if not port.isdigit() or not 0 < int(port) < 65536:
        raise links.LinkError("Remote proxy must look like host:port, e.g. proxy.example.com:8080")
    return host, int(port)


def _udp_server(t):
    """How a saved UDP tweak's server is shown back in the form: host:port or host:from-to."""
    if not t or t.protocol != "udp" or not t.host:
        return ""
    host = f"[{t.host}]" if ":" in t.host else t.host
    return f"{host}:{t.cfg.get('form', {}).get('port_spec') or t.port}"


def _split_host_port(host, port):
    """Accept 'host:port' (or '[ipv6]:port') typed into the host box, as injector apps show it."""
    host = re.sub(r"^[a-z]+://", "", (host or "").strip(), flags=re.I).rstrip("/")
    if host.startswith("["):
        h, _, rest = host.partition("]")
        if rest.startswith(":") and rest[1:].isdigit():
            return h[1:], int(rest[1:])
        return host, port
    if host.count(":") == 1:
        h, p = host.split(":")
        if p.isdigit() and 0 < int(p) < 65536:
            return h.strip(), int(p)
    return host, port


def _normalize_payload(text):
    """A real line break in the payload box means "next header line". Store it as [crlf] so what is saved is
    exactly what is sent. A break inside a [tag], or right after a [crlf]-style tag, is just text wrapping."""
    t = (text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    t = re.sub(r"\[[^\]]*\]", lambda m: m.group(0).replace("\n", ""), t)
    t = re.sub(r"(?i)(\[(?:crlf|lf|cr)\])\n+", r"\1", t)
    return t.replace("\n", "[crlf]")


def _fill_tweak(s, f, files=None):
    """Apply the form to a Tweak. Raises links.LinkError with a friendly message."""
    proto = f.get("protocol", "ssh")
    if proto not in PROTOCOLS:
        raise links.LinkError("Pick a protocol")
    name = f.get("name", "").strip()
    host, port = f.get("host", "").strip(), f.get("port", type=int) or 0
    cfg = {}
    if proto == "ssh":
        host, port = _split_host_port(host, port)
        if not host or not port or not f.get("ssh_username", "").strip():
            raise links.LinkError("SSH needs the SSH host, port and username")
        payload = f.get("ssh_payload", "")
        up = files.get("payload_file") if files else None
        if up and up.filename:
            try:
                payload = up.read(50_000).decode("utf-8")
            except UnicodeDecodeError:
                raise links.LinkError("The payload file is not plain text")
        proxy_host, proxy_port = _parse_proxy(f.get("ssh_proxy", ""))
        cfg = {"username": f["ssh_username"].strip(), "password": f.get("ssh_password", ""),
               "payload": _normalize_payload(payload), "sni": f.get("ssh_sni", s.cfg.get("sni", "")).strip(),
               "proxy_host": proxy_host, "proxy_port": proxy_port}
    elif proto == "v2ray":
        uuid, link = f.get("v2_uuid", "").strip(), f.get("v2ray_link", "").strip()
        host, port = _split_host_port(host, port)
        if uuid:
            form = {"proto": f.get("v2_proto", "vless"), "uuid": uuid, "network": f.get("v2_network", "ws"),
                    "path": f.get("v2_path", "").strip(), "host_header": f.get("v2_hosthdr", "").strip(),
                    "sni": f.get("v2_sni", "").strip(), "tls": bool(f.get("v2_tls"))}
            out = links.build_v2ray(form["proto"], host, port, uuid, form["network"], form["path"],
                                    form["host_header"], form["tls"], form["sni"])
            cfg = {"outbound": out, "form": form}
        elif link:
            p = links.parse_link(link)
            cfg, host, port = {"link": link, "outbound": p["outbound"]}, p["host"], p["port"]
            name = name or p["name"]
        elif s.cfg.get("outbound"):
            cfg = s.cfg
        else:
            raise links.LinkError("V2Ray needs the server host, port and UUID (or paste a share link)")
    elif proto == "udp":
        server_host, server_ports = links.split_server(f.get("udp_server", ""))
        first_port, port_spec = links.parse_ports(server_ports)
        host, port = server_host, first_port
        form = {"username": f.get("udp_username", "").strip(), "password": f.get("udp_password", ""),
                "sni": f.get("udp_sni", "").strip(), "pin": f.get("udp_pin", "").strip(),
                "cert_name": f.get("udp_certname", "").strip(), "port_spec": port_spec}
        cfg = {"outbound": links.build_udp(host, port_spec, form["username"], form["password"], form["sni"], form["pin"],
                                           form["cert_name"]),
               "form": form}
    elif proto == "wireguard":
        conf = f.get("wg_conf", "").strip()
        if not conf and s.cfg.get("outbound"):
            cfg = s.cfg
        else:
            p = links.parse_wg_conf(conf)
            cfg, host, port = {"wg_conf": conf, "outbound": p["outbound"]}, p["host"], p["port"]
    else:
        out = links.parse_custom(f.get("custom_outbound", ""))
        cfg = {"outbound": out}
        host, port = host or "custom", port or 0
    if not name:
        raise links.LinkError("Give the tweak a name")
    expires = f.get("expires_at", "").strip()
    try:
        s.expires_at = datetime.strptime(expires, "%Y-%m-%d") if expires else None
    except ValueError:
        raise links.LinkError("Expiry must look like 2026-12-31")
    s.name, s.protocol, s.host, s.port, s.cfg = name[:80], proto, host, port, cfg
    s.country_code = f.get("country_code", "").strip().upper()[:2]
    s.description = f.get("description", "").strip()[:200]
    s.sort = f.get("sort", type=int) or 0
    s.is_active = bool(f.get("is_active"))


@bp.route("/tweaks/new", methods=["GET", "POST"])
@bp.route("/tweaks/<int:sid>", methods=["GET", "POST"])
@admin_required
def tweak_form(sid=None):
    s = db.session.get(Tweak, sid) if sid else None
    if sid and not s:
        return redirect(url_for("admin.home", tab="tweaks"))
    values = _tweak_values(s)
    if request.method == "POST":
        target = s or Tweak(protocol="ssh", data="{}")
        try:
            _fill_tweak(target, request.form, request.files)
        except links.LinkError as e:
            flash(str(e), "error")
            values = {**values, **{k: v for k, v in request.form.items()},
                      "is_active": bool(request.form.get("is_active"))}
        else:
            db.session.add(target)
            bump_rev()
            db.session.commit()
            flash(f"Saved {target.name}.", "ok")
            return redirect(url_for("admin.home", tab="tweaks"))
    return render_template("tweak_form.html", t=s, v=values)


@bp.post("/tweaks/<int:sid>/delete")
@admin_required
def tweak_delete(sid):
    s = db.session.get(Tweak, sid)
    if s:
        db.session.delete(s)
        bump_rev()
        db.session.commit()
    return redirect(url_for("admin.home", tab="tweaks"))


@bp.post("/tweaks/<int:sid>/toggle")
@admin_required
def tweak_toggle(sid):
    s = db.session.get(Tweak, sid)
    if s:
        s.is_active = not s.is_active
        bump_rev()
        db.session.commit()
    return redirect(url_for("admin.home", tab="tweaks"))


@bp.post("/tweaks/<int:sid>/duplicate")
@admin_required
def tweak_duplicate(sid):
    s = db.session.get(Tweak, sid)
    if s:
        c = Tweak(name=f"{s.name} (copy)", country_code=s.country_code, protocol=s.protocol, host=s.host,
                   port=s.port, description=s.description, expires_at=s.expires_at, is_active=False, sort=s.sort, data=s.data)
        db.session.add(c)
        bump_rev()
        db.session.commit()
        flash("Duplicated (hidden until you enable it).", "ok")
    return redirect(url_for("admin.home", tab="tweaks"))


# ------------------------------------------------------------------ import / export / settings

@bp.post("/import-links")
@admin_required
def import_links():
    added, errors = 0, []
    for i, line in enumerate(request.form.get("lines", "").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            if "://" in line and line.split("://", 1)[0].lower() in ("vmess", "vless", "trojan", "ss"):
                p = links.parse_link(line)
                db.session.add(Tweak(name=p["name"][:80], protocol="v2ray", host=p["host"], port=p["port"],
                                      cfg={"link": line, "outbound": p["outbound"]}))
            else:
                p = links.parse_ssh_line(line)
                db.session.add(Tweak(name=f"SSH {p['host']}", protocol="ssh", host=p["host"], port=p["port"],
                                      cfg={"username": p["username"], "password": p["password"], "payload": "",
                                           "sni": "", "proxy_host": "", "proxy_port": 0}))
            added += 1
        except links.LinkError as e:
            errors.append(f"line {i}: {e}")
    if added:
        bump_rev()
        db.session.commit()
    flash(f"Added {added} tweak(s)." + (" Problems: " + "; ".join(errors[:5]) if errors else ""),
          "ok" if added and not errors else "error")
    return redirect(url_for("admin.home", tab="tweaks"))


@bp.post("/import-bundle")
@admin_required
def import_bundle_route():
    up = request.files.get("bundle")
    try:
        data = json.loads(up.read().decode("utf-8")) if up and up.filename else None
        if is_locked(data):
            data = json.loads(unlock(data, current_app.config["CONFIG_KEY"]).decode("utf-8"))
        n = import_bundle(data, replace=bool(request.form.get("replace")))
        flash(f"Imported {n} tweak(s).", "ok")
    except (ValueError, KeyError, TypeError) as e:
        db.session.rollback()
        flash(f"Import failed: {e}", "error")
    return redirect(url_for("admin.home", tab="backup"))


@bp.get("/export")
@admin_required
def export():
    """Share file for users: locked when CONFIG_KEY is set. ?plain=1 gives a readable admin backup."""
    plain = json.dumps(build_bundle(public=False), indent=2, ensure_ascii=False)
    key = current_app.config["CONFIG_KEY"]
    if request.args.get("plain") or not key:
        name = "genzvpn-backup-PLAIN.json" if key else "genzvpn-config.json"
        return Response(plain, mimetype="application/json",
                        headers={"Content-Disposition": f"attachment; filename={name}"})
    return Response(lock(plain.encode(), key), mimetype="application/json",
                    headers={"Content-Disposition": "attachment; filename=genzvpn-config.json"})


@bp.post("/settings")
@admin_required
def settings():
    url = request.form.get("channel_url", "").strip()
    ok = not url or re.match(r"^https://(www\.)?whatsapp\.com/channel/[A-Za-z0-9_-]+/?$", url)
    if not ok:
        flash("That does not look like a WhatsApp channel link (https://whatsapp.com/channel/...).", "error")
    else:
        set_setting("channel_url", url)
        bump_rev()
        db.session.commit()
        flash("Saved.", "ok")
    return redirect(url_for("admin.home", tab="settings"))


@bp.post("/notices")
@admin_required
def notice_add():
    title, message = request.form.get("title", "").strip()[:80], request.form.get("message", "").strip()[:1000]
    if not title:
        flash("Give the notification a title.", "error")
    else:
        db.session.add(Notice(title=title, message=message))
        bump_rev()
        db.session.commit()
        flash("Sent. Users see it after they tap Update.", "ok")
    return redirect(url_for("admin.home", tab="notices"))


@bp.post("/notices/<int:nid>/delete")
@admin_required
def notice_delete(nid):
    n = db.session.get(Notice, nid)
    if n:
        db.session.delete(n)
        bump_rev()
        db.session.commit()
    return redirect(url_for("admin.home", tab="notices"))


# ------------------------------------------------------------------ adverts shown in the app

def _https_or_blank(text):
    """Only https links are kept, so an advert can never point the app at something else."""
    text = (text or "").strip()[:500]
    return text if text.lower().startswith("https://") and " " not in text else ""


@bp.post("/ads")
@admin_required
def ad_add():
    f = request.form
    title = f.get("title", "").strip()[:80]
    if not title:
        flash("Give the ad a title.", "error")
    else:
        link, image = _https_or_blank(f.get("link_url")), _https_or_blank(f.get("image_url"))
        if (f.get("link_url", "").strip() and not link) or (f.get("image_url", "").strip() and not image):
            flash("Links and image addresses must start with https://", "error")
        else:
            db.session.add(Ad(title=title, message=f.get("message", "").strip()[:1000], image_url=image,
                              link_url=link, button=f.get("button", "").strip()[:30]))
            bump_rev()
            db.session.commit()
            flash("Ad posted. Users see it after they tap Update.", "ok")
    return redirect(url_for("admin.home", tab="ads"))


@bp.post("/ads/<int:aid>/toggle")
@admin_required
def ad_toggle(aid):
    a = db.session.get(Ad, aid)
    if a:
        a.is_active = not a.is_active
        bump_rev()
        db.session.commit()
    return redirect(url_for("admin.home", tab="ads"))


@bp.post("/ads/<int:aid>/delete")
@admin_required
def ad_delete(aid):
    a = db.session.get(Ad, aid)
    if a:
        db.session.delete(a)
        bump_rev()
        db.session.commit()
    return redirect(url_for("admin.home", tab="ads"))


# ------------------------------------------------------------------ the Android app (APK)

def _apk_apply(r, f, files, new):
    """Fill a release from the form and store its file. Returns an error message or None."""
    name, version = f.get("app_name", "").strip()[:60], f.get("version", "").strip()[:30]
    if not name or not version:
        return "Give the app name and the version."
    upload = files.get("apk")
    has_file = bool(upload and upload.filename)
    if new and not has_file:
        return "Choose the APK file to upload."
    r.app_name, r.version = name, version
    r.notes = f.get("notes", "").strip()[:4000]
    r.is_published = bool(f.get("is_published"))
    if has_file:
        if not upload.filename.lower().endswith(".apk"):
            return "The file must end in .apk"
        try:
            apk_service.check_apk(upload.stream)
        except apk_service.ApkError as e:
            return str(e)
        if new:
            db.session.add(r)
            db.session.flush()  # the file pieces need the release id
        apk_service.store(r, upload.stream)
    return None


@bp.post("/app/upload")
@admin_required
def apk_upload():
    r = ApkRelease()
    err = _apk_apply(r, request.form, request.files, new=True)
    if err:
        db.session.rollback()
        flash(err, "error")
    else:
        db.session.commit()
        flash(f"Uploaded {r.app_name} {r.version}. " + ("The home page now shows the download button." if r.is_published
              else "It is hidden until you publish it."), "ok")
    return redirect(url_for("admin.home", tab="app"))


@bp.route("/app/<int:rid>", methods=["GET", "POST"])
@admin_required
def apk_edit(rid):
    r = db.session.get(ApkRelease, rid)
    if r is None:
        return redirect(url_for("admin.home", tab="app"))
    if request.method == "POST":
        err = _apk_apply(r, request.form, request.files, new=False)
        if err:
            db.session.rollback()
            flash(err, "error")
        else:
            db.session.commit()
            flash("Saved.", "ok")
            return redirect(url_for("admin.home", tab="app"))
    return render_template("apk_form.html", r=r)


@bp.post("/app/<int:rid>/toggle")
@admin_required
def apk_toggle(rid):
    r = db.session.get(ApkRelease, rid)
    if r:
        r.is_published = not r.is_published
        db.session.commit()
    return redirect(url_for("admin.home", tab="app"))


@bp.post("/app/<int:rid>/delete")
@admin_required
def apk_delete(rid):
    r = db.session.get(ApkRelease, rid)
    if r:
        apk_service.remove(r)
        db.session.delete(r)
        db.session.commit()
        flash("Deleted.", "ok")
    return redirect(url_for("admin.home", tab="app"))


# ------------------------------------------------------------------ the free apps library (admin uploads, users download)

def _freeapp_apply(a, f, files, new):
    """Fill a free app from the form and store its file. Returns an error message or None."""
    name, version = f.get("name", "").strip()[:60], f.get("version", "").strip()[:30]
    if not name:
        return "Give the app a name."
    upload = files.get("apk")
    has_file = bool(upload and upload.filename)
    if new and not has_file:
        return "Choose the APK file to upload."
    if new and not f.get("rights"):
        return "Tick the box to confirm you are allowed to share this app."
    a.name, a.version = name, version
    a.description = f.get("description", "").strip()[:1000]
    a.is_published = bool(f.get("is_published"))
    if has_file:
        if not upload.filename.lower().endswith(".apk"):
            return "The file must end in .apk"
        if not f.get("rights"):
            return "Tick the box to confirm you are allowed to share this app."
        try:
            free_service.check_apk(upload.stream)
        except free_service.ApkError as e:
            return str(e)
        if new:
            db.session.add(a)
            db.session.flush()  # the file pieces need the app id
        free_service.store(a, upload.stream)
    return None


@bp.post("/freeapps/upload")
@admin_required
def freeapp_upload():
    a = FreeApp()
    err = _freeapp_apply(a, request.form, request.files, new=True)
    if err:
        db.session.rollback()
        flash(err, "error")
    else:
        db.session.commit()
        flash(f"Uploaded {a.name}. " + ("Users can download it from the home page now." if a.is_published
              else "It is hidden until you publish it."), "ok")
    return redirect(url_for("admin.home", tab="freeapps"))


@bp.route("/freeapps/<int:aid>", methods=["GET", "POST"])
@admin_required
def freeapp_edit(aid):
    a = db.session.get(FreeApp, aid)
    if a is None:
        return redirect(url_for("admin.home", tab="freeapps"))
    if request.method == "POST":
        err = _freeapp_apply(a, request.form, request.files, new=False)
        if err:
            db.session.rollback()
            flash(err, "error")
        else:
            db.session.commit()
            flash("Saved.", "ok")
            return redirect(url_for("admin.home", tab="freeapps"))
    return render_template("freeapp_form.html", a=a)


@bp.post("/freeapps/<int:aid>/toggle")
@admin_required
def freeapp_toggle(aid):
    a = db.session.get(FreeApp, aid)
    if a:
        a.is_published = not a.is_published
        db.session.commit()
    return redirect(url_for("admin.home", tab="freeapps"))


@bp.post("/freeapps/<int:aid>/delete")
@admin_required
def freeapp_delete(aid):
    a = db.session.get(FreeApp, aid)
    if a:
        free_service.remove(a)
        db.session.delete(a)
        db.session.commit()
        flash("Deleted.", "ok")
    return redirect(url_for("admin.home", tab="freeapps"))


# ------------------------------------------------------------------ requests sent by users

@bp.post("/requests/<int:rid>/status")
@admin_required
def request_status(rid):
    r = db.session.get(UserRequest, rid)
    status = request.form.get("status", "")
    if r and status in REQUEST_STATUSES:
        r.status = status
        db.session.commit()
    return redirect(url_for("admin.home", tab="requests", show=request.form.get("show", "open")))


@bp.post("/requests/<int:rid>/delete")
@admin_required
def request_delete(rid):
    r = db.session.get(UserRequest, rid)
    if r:
        db.session.delete(r)
        db.session.commit()
    return redirect(url_for("admin.home", tab="requests", show=request.form.get("show", "open")))
