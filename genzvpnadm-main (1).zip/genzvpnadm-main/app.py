import time
import logging

import click
from flask import Flask, render_template

from config import Config
from models import Admin, db


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)
    logging.basicConfig(level=logging.INFO)
    if app.config["PROXY_HOPS"]:
        from werkzeug.middleware.proxy_fix import ProxyFix
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=app.config["PROXY_HOPS"], x_proto=app.config["PROXY_HOPS"])
    db.init_app(app)

    from routes import admin, api, web
    from routes.common import csrf_token
    for m in (web, admin, api):
        app.register_blueprint(m.bp)

    @app.before_request
    def limit_uploads():
        """Each page has its own limit: the VPN app APK, the free apps, and 2 MB for everything else."""
        from flask import abort, request
        mb = 1024 * 1024
        limit = {"admin.apk_upload": app.config["MAX_UPLOAD_MB"] * mb, "admin.apk_edit": app.config["MAX_UPLOAD_MB"] * mb,
                 "admin.freeapp_upload": app.config["FREE_APP_MAX_MB"] * mb,
                 "admin.freeapp_edit": app.config["FREE_APP_MAX_MB"] * mb}.get(request.endpoint, app.config["SMALL_UPLOAD_LIMIT"])
        if (request.content_length or 0) > limit:
            abort(413, "That file is too large.")

    @app.context_processor
    def inject():
        return {"csrf_token": csrf_token}

    @app.template_filter("filesize")
    def filesize(n):
        n = float(n or 0)
        for unit in ("B", "KB", "MB", "GB"):
            if n < 1024 or unit == "GB":
                return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
            n /= 1024

    @app.template_filter("flag")
    def flag(code):
        code = (code or "").upper()
        return "".join(chr(0x1F1E6 + ord(c) - 65) for c in code) if len(code) == 2 and code.isalpha() else ""

    @app.after_request
    def headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self' https://fonts.googleapis.com; "
            "font-src https://fonts.gstatic.com; img-src 'self' data:; script-src 'self'")
        if not resp.headers.get("Cache-Control"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(400)
    @app.errorhandler(404)
    @app.errorhandler(413)
    def oops(e):
        return render_template("error.html", code=e.code, message=getattr(e, "description", "")), e.code

    def first_start():
        db.create_all()
        email, pw = app.config["ADMIN_EMAIL"].strip().lower(), app.config["ADMIN_PASSWORD"]
        if email and pw and not Admin.query.filter_by(email=email).first():
            a = Admin(email=email)
            a.set_password(pw)
            db.session.add(a)
            db.session.commit()
        if app.config["SEED_DEFAULT_TWEAK"]:
            from services.defaults import seed_default_tweak
            seed_default_tweak()

    with app.app_context():
        # Several server workers boot at the same moment on a fresh database and would each create the tables and the
        # first admin. The loser of that race gets a "already exists" error; it must wait and carry on, not crash.
        from sqlalchemy.exc import DBAPIError
        for attempt in range(6):
            try:
                first_start()
                break
            except DBAPIError:
                db.session.rollback()
                if attempt == 5:
                    raise
                time.sleep(0.4 * (attempt + 1))

    @app.cli.command("create-admin")
    @click.argument("email")
    @click.password_option()
    def create_admin(email, password):
        email = email.strip().lower()
        a = Admin.query.filter_by(email=email).first() or Admin(email=email)
        a.set_password(password)
        db.session.add(a)
        db.session.commit()
        click.echo(f"Admin ready: {email}. Sign in at /admin")

    return app
